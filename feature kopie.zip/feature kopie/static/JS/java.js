/*jslint browser: true, devel: true, eqeq: true, plusplus: true, sloppy: true, vars:
true, white: true*/
/*eslint-env browser*/
/*eslint 'no-console':0*/
/* exported myFunction */

/*CODE voor hamburger menu van Carlijn Bruin*/
/*
var zoekbutton = document.querySelector(".burger");
var zoekveld = document.querySelector(".linkjes");

function show() {
	zoekveld.classList.toggle("show-search");
}

zoekbutton.addEventListener("click", show);
*/

console.log('hellow :)');

// dit zijn de notificatie div'jes
let boost = document.getElementById('noteBoost');
let likes = document.getElementById('noteLikes');
let messages = document.getElementById('noteMessages');

// dit zijn de nummers in p
let valueBoost = document.getElementById('valueBoost');
let valueLikes = document.getElementById('valueLikes');
let valueMessages = document.getElementById('valueMessages');

let type = [boost, likes, messages];
let value = [valueBoost, valueLikes, valueMessages];

function notifyBoost {
	if(valueBoost > 0){
		// https://stackoverflow.com/questions/9456289/how-to-make-a-div-visible-and-invisible-with-javascript
		boost.style.visibility = 'visible';
		// https://www.w3schools.com/js/js_htmldom_html.asp
		document.getElementById("valueBoost").innerHTML = "1";
	} else {
		boost.style.visibility = 'hidden'; // hide, but lets the element keep its size
	}
}

// var boost = document.querySelector("#boost");
// var boostActive = document.querySelector("#boostActive");
//
// function show() {
// 	boostActive.classList.toggle("active");
// }
//
// boost.addEventListener("click", show);
